package org.ieselcaminas.conversor;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.layout.VBox;

public class ConverterView {
    private VBox root;

    public ConverterView() {
        buildUI();
    }

    private void buildUI() {
        root = new VBox(20);
        root.setPadding(new Insets(32, 36, 32, 36));
        root.setAlignment(Pos.TOP_CENTER);
    }
    public VBox getRoot() {
        return root;
    }
}
