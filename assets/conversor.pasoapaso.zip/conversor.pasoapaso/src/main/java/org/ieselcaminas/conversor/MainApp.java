package org.ieselcaminas.conversor;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) {
        ConverterView view = new ConverterView();
        Scene scene = new Scene(view.getRoot(), 780, 680);

        stage.setTitle("Conversor de Distancias");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
