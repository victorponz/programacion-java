package del1al5;
//Un programa que calcula una división y una suma entera
public class Ejemplo2 {

    public static void main(String[] args) {

        int dividendo = 20;

        int divisor = 6;

        int sumarAlFinal = 3;

        System.out.println((dividendo/divisor) + sumarAlFinal);

    }

}