package del1al5;
//Un programa que calcula una división y una suma.
public class Ejemplo1 {
	public static void main(String[] args) {

        double dividendo = 20.0;

        double divisor = 6.0;

        double sumarAlFinal = 3.0;

        System.out.println((dividendo/divisor) + sumarAlFinal);

    }
}
